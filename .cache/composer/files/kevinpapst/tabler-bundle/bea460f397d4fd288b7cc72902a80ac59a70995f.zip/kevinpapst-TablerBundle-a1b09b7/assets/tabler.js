require('./tabler.scss');

require('@tabler/core/dist/js/tabler');
