require('./tabler-rtl.scss');

require('@tabler/core/dist/js/tabler');
