# Using the layout

In order to use the layout, your error views should extend from the provided `error layout`
```twig
{% extends '@Tabler/error.html.twig' %}
```

## Layout blocks

TODO explain blocks

## Extra

You can follow the symfony tutorial to create your own error templates: https://symfony.com/doc/current/controller/error_pages.html

## Next steps

Please go back to the [Tabler bundle documentation](README.md) to find out more about using the theme.
