Twig CssInliner Extension
=========================

This package is a Twig extension that provides the following:

 * [`inline_css`][1] filter: inlines CSS styles in HTML documents.

[1]: https://twig.symfony.com/inline_css
