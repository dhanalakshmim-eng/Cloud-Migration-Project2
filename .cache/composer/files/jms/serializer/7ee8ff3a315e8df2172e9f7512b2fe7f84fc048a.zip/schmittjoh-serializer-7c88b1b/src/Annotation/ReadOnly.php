<?php

declare(strict_types=1);

use JMS\Serializer\Annotation\DeprecatedReadOnly;

class_alias(DeprecatedReadOnly::class, 'JMS\Serializer\Annotation\ReadOnly');
